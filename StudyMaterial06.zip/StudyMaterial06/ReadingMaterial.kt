----------------------------------------------------------

Java Object Class Documentation	
	https://docs.oracle.com/javase/8/docs/api/java/lang/Object.html

----------------------------------------------------------

Android Reading Material
	https://developer.android.com/guide/platform


______________________________________________________________

DAY 01
______________________________________________________________

	Assingment 01: Practice and Experiment Kotlin Code
		Practice and Experiment Kotlin Code Done Till Now

	Assingment 02: Revise/Study Java
		Revise Classes and Interfaces Topics
		
______________________________________________________________

DAY 02
______________________________________________________________

	Assingment A1: Practice and Experiment Kotlin Code
		Practice and Experiment Kotlin Code Done Till Now

	Assingment A2: Revise/Study Java
		Core Java for the Impatient 3rd Edition by Cay S. Horstmann (Author)
		Study Classes and Interfaces Chapter

	Assingment A3: Experimentation and Exploration
		1. Experiment Following Code In C/C++/Python/Kotlin/JS
			Reason The Output as well as Design Decisions In Each Language

		2. What Is Mathematical Definfitions And Which Language Implements What?

		public static void playWithNumbers() {
			// try {
			System.out.println(  1.0 / 0.0 );
			System.out.println( -1.0 / 0.0 );
			System.out.println(  0.0 / 0.0 );
			// } catch () {

			// }
			System.out.println(  1.0 / 0.0 == Double.POSITIVE_INFINITY);
			System.out.println( -1.0 / 0.0 == Double.NEGATIVE_INFINITY);
			System.out.println(  0.0 / 0.0 == Double.NaN );

			// BEST PRACTICE
			System.out.println(  Double.isInfinite( 1.0 / 0.0 ) );
			System.out.println(  Double.isFinite( -1.0 / 0.0 )  );
			System.out.println(  Double.isNaN( 0.0 / 0.0)  );

			// System.out.println( 1 / 0 );		
			// System.out.println( );
			// System.out.println( );
		}

______________________________________________________________

DAY 03
______________________________________________________________

	Assingment A1: Practice and Experiment Kotlin Code
		Practice and Experiment Kotlin Code Done Till Now

	Assingment A2: Revise/Study Java
		Core Java for the Impatient 3rd Edition by Cay S. Horstmann (Author)
		Study Classes and Interfaces Chapter
		Higher Order Functions

	Assingment A3: Experimentation and Exploration
		Parent and Child Example Experiment In Java
		Experiment Higher Order Functions In Java
		Value Capture Experiment In Java

______________________________________________________________

DAY 04
______________________________________________________________

	Assingment A1: Practice and Experiment Kotlin Code
		Practice and Experiment Kotlin Code Done Till Now

	Assingment A2: Revise/Study Java
		Reference:
			Core Java for the Impatient 3rd Edition by Cay S. Horstmann (Author)
		Study Classes and Interfaces Chapter
		Higher Order Functions

	Assingment A3: Revise/Study Kotlin
		Reference:
			Kotlin in Action, Second Edition 2nd Edition
				by Sebastian Aigner (Author), Roman Elizarov (Author), 
				Svetlana Isakova (Author), & 1 more
			
			Chapter 01 To 04 [ INCLUSIVE ]
				Read and Experiment Kotlin Code
				Compare With Java Code Also

	Assingment A4: Experimentation and Exploration
		Parent and Child Example Experiment In Java
		Experiment Higher Order Functions In Java
		Value Capture Experiment In Java

	Assingment A5: Advance Reading and Experimentation Assignments
		https://docs.oracle.com/javase/8/docs/api/java/lang/Object.html
		Create Use Cases Where Equality and/or Hashcode Contract Violated

______________________________________________________________

DAY 05
______________________________________________________________

	Assingment A1: Practice and Experiment Kotlin Code
		Practice and Experiment Kotlin Code Done Till Now

	Assingment A2: Revise/Study Java
		Reference:
			Core Java for the Impatient 3rd Edition by Cay S. Horstmann (Author)
		Study Classes and Interfaces Chapter
		Higher Order Functions

	Assingment A3: Revise/Study Kotlin
		Reference:
			Kotlin in Action, Second Edition 2nd Edition
				by Sebastian Aigner (Author), Roman Elizarov (Author), 
				Svetlana Isakova (Author), & 1 more
			
			Chapter 01 To 04 [ INCLUSIVE ]
				Read and Experiment Kotlin Code
				Compare With Java Code Also

	Assingment A4: Experimentation and Exploration
		Parent and Child Example Experiment In Java
		Experiment Higher Order Functions In Java
		Value Capture Experiment In Java

______________________________________________________________

DAY 06
______________________________________________________________

	Assingment A1: Practice and Experiment Kotlin Code
		Practice and Experiment Kotlin Code Done Till Now

	Assingment A2: Revise/Study Java
		Reference:
			Core Java for the Impatient 3rd Edition by Cay S. Horstmann (Author)
		Study Classes and Interfaces Chapter
		Higher Order Functions

	Assingment A3: Revise/Study Kotlin
		Reference:
			Kotlin in Action, Second Edition 2nd Edition
				by Sebastian Aigner (Author), Roman Elizarov (Author), 
				Svetlana Isakova (Author), & 1 more
			
			Chapter 05 To 07 [ INCLUSIVE ]
				Read and Experiment Kotlin Code
				Compare With Java Code Also

______________________________________________________________

DAY 07
______________________________________________________________

	Assingment A1: Practice and Experiment Kotlin Code
		Practice and Experiment Kotlin Code Done Till Now

	Assingment A2: Revise/Study Java
		Reference:
			Core Java for the Impatient 3rd Edition by Cay S. Horstmann (Author)
		Study Classes and Interfaces Chapter
		Higher Order Functions
		Collections Chapter
		Lambdas Chapter

	Assingment A3: Revise/Study Kotlin
		Reference:
			Kotlin in Action, Second Edition 2nd Edition
				by Sebastian Aigner (Author), Roman Elizarov (Author), 
				Svetlana Isakova (Author), & 1 more
			
			Chapter 01 To 07 [ INCLUSIVE ]
				Read and Experiment Kotlin Code
				Compare With Java Code Also

	Assignment A4: Android Code Exploration And Understanding
		Complete Following Android Code Examples
		
		AndroidCode00.zip
			├── TestHelloWorld

	Assingment A5: Android Reading Assignments
		https://developer.android.com/guide/platform
		https://developer.android.com/guide/components/activities/activity-lifecycle

______________________________________________________________

DAY 08
______________________________________________________________

	Assignment A1: Android Code Exploration And Understanding
		Complete Following Android Code Examples

		AndroidCode01.zip
			├── AndroidCode01
			│ 	1.  ManifestAndResourcesJava
			│ 	2.  ActivitiesJava
			│ 	3.  ConfigChangesJava

		AndroidCode02.zip
		├── AndroidCode02
		│ 	1.  Project.04.01.Layouts
		│ 	2. 	Project.04.03.Views

		AndroidCode02.zip
		├── AndroidCode02
		│ 	3.  Project.04.04.Adapters

	Assingment A2: Android Reading Assignments
		https://developer.android.com/guide/platform
		https://developer.android.com/guide/components/activities/activity-lifecycle

		https://developer.android.com/guide/topics/resources/runtime-changes
		https://developer.android.com/develop/ui/views/layout/declaring-layout

	Assingment A3: Android Reading And Coding Assignments

		AndroidProgrammingTheBigNerdRanchGuide4E-PART1.pdf
	
	Assingment A4: Advanced Android Reading Assignments [ OPTIONAL ]

		https://developer.android.com/reference/android/view/View

______________________________________________________________

DAY 09
______________________________________________________________

	Assignment A1: Android Code Exploration And Understanding
		Complete Following Android Code Examples

		AndroidCode02.zip
		├── AndroidCode02
		│ 	3.  Project.04.04.Adapters


		AndroidCode03.zip		
		├── Android.Code.Fragements
			1. AndroidFragmentFundamentals
			2. AndroidFragmentPizza

	Assingment A2: Android Reading And Coding Assignments

		AndroidProgrammingTheBigNerdRanchGuide4E-PART1.pdf
		AndroidProgrammingTheBigNerdRanchGuide4E-PART2.pdf
	
	Assingment A3: Android Reading Assignments
		https://developer.android.com/guide/fragments
		https://developer.android.com/guide/fragments/lifecycle

______________________________________________________________

DAY 10
______________________________________________________________

	Assingment A4: Inquistive and Brave Hearts! [ OPTIONAL ASSIGNMENT ]
		Reading Pointers and Arrays Chapter
		Reference: The C Programming Language, 2nd Edition

	Assingment A5: Advance Reading and Experimentation Assignments
		https://docs.oracle.com/javase/8/docs/api/java/lang/Object.html
		Create Use Cases Where Equality and/or Hashcode Contract Violated

		Serialization Issues
		https://github.com/pmd/pmd/issues/2992
		https://docs.oracle.com/en/java/javase/11/docs/specs/serialization/serial-arch.html#the-serializable-interface

	Assingment A6: Inquistive and Brave Hearts! [ OPTIONAL ASSIGNMENT ]
		Reading Pointers and Arrays Chapter
		Reference: The C Programming Language, 2nd Edition

		Effective Java
		https://ahdak.github.io/blog/effective-java-part-3/
		https://github.com/HugoMatilla/Effective-JAVA-Summary?tab=readme-ov-file#22-favor-static-member-classes-over-nonstatic
		https://github.com/HugoMatilla/Effective-JAVA-Summary#4-classes-and-interfaces

	Assingment A5: Advance Reading and Experimentation Assignments
		Coroutines
			https://kotlinlang.org/docs/coroutines-basics.html
			https://kotlinlang.org/docs/channels.html
			https://kotlinlang.org/docs/cancellation-and-timeouts.html

______________________________________________________________
 
 BUILD FUTURE AND THINKING WORK
______________________________________________________________



______________________________________________________________


----------------------------------------------------------
----------------------------------------------------------

https://codebunk.com/b/4901100677322/
https://codebunk.com/b/4901100677322/

https://codebunk.com/b/6371100678022/
https://codebunk.com/b/6371100678022/

----------------------------------------------------------

https://github.com/amarjitlife/HSBCAug2024
https://github.com/amarjitlife/HSBCAug2024
https://github.com/amarjitlife/HSBCAug2024

----------------------------------------------------------

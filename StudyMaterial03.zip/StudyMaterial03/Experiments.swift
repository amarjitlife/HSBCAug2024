
print("Welcome To Swift!!!")
print("Unicode Concepts!!!")

let eAcute: Character = "\u{E9}"
let eAcuteAgain: Character = "\u{65}\u{301}"

print( eAcute )
print( eAcuteAgain )

// é
// é

let precomposed: Character = "\u{D55C}"                  // 한
let decomposed: Character = "\u{1112}\u{1161}\u{11AB}"   // ᄒ, ᅡ, ᆫ
// precomposed is 한, decomposed is 한

print( precomposed )
print( decomposed )



package learnKotlin

//_______________________________________________________

// Function Type
//		(Int, Int) -> Int

fun sum(a: Int, b: Int) = a + b
fun sub(a: Int, b: Int) = a - b

// Higher Order Functions
//		Function Which Takes And/Or Returns Functions

// Function Type
//		(Int, Int, (Int, Int) -> Int) -> Int 
fun calculator( a: Int, b: Int, operation: (Int, Int) -> Int ) : Int {
	return operation( a, b )
}

fun playWithCalculator() {
	val a = 40
	val b = 20
	var result = 0

	result = calculator( a, b, ::sum )
	println("Result = $result ")

	result = calculator( a, b, ::sub )
	println("Result = $result ")

	// What Is The Type Of something?
	val something: (Int, Int) -> Int = ::sum
	result = something( 100, 200 )
	println("Result = $result ")

	val somethingAgain = ::sum
	result = somethingAgain( 100, 200 )
	println("Result = $result ")

	// What Is The Type Of somethingMore?
	val somethingMore = ::calculator
	result = somethingMore(111, 222, ::sum )
	println("Result = $result ")

	val somethingOnceMore: (Int, Int, (Int, Int) -> Int) -> Int = ::calculator
	result = somethingMore(111, 222, ::sum )
	println("Result = $result ")
}

//_______________________________________________________

fun chooseSteps( backward: Boolean ) : (Int) -> Int {
	fun moveForward( start: Int ) : Int {
		return start + 1
	}

	fun moveBackward( start: Int ) : Int {
		return start -  1 
	}

	return	if ( backward ) ::moveBackward else ::moveForward 
}

fun playWithChooseSteps() {
	val something: (Int) -> Int = chooseSteps( true )

	var result = something( 100 )
	println("Result = $result ")

	val somethingMore: (Boolean) -> (Int) -> Int = ::chooseSteps
	val somethingOnceMore: (Int) -> Int = somethingMore( false )
	val YeDilMaangeMore = somethingOnceMore(10)


}


//_______________________________________________________

// fun calculator( a: Int, b: Int, operation: (Int, Int) -> Int ) : Int {
// 	return operation( a, b )
// }

fun playWithCalculatorAgain() {
	val a = 40
	val b = 20
	var result = 0


	val sumLambda: (Int, Int) -> Int = { a: Int, b: Int  -> a + b }
	result = calculator( a, b, sumLambda )
	println("Result = $result ")

	val subLambda: (Int, Int) -> Int = { a: Int, b: Int  -> a - b }
	result = calculator( a, b, subLambda )
	println("Result = $result ")

	// What Is The Type Of something?
	val something: (Int, Int) -> Int = ::sum
	result = something( 100, 200 )
	println("Result = $result ")

	val somethingAgain = ::sum
	result = somethingAgain( 100, 200 )
	println("Result = $result ")

	// What Is The Type Of somethingMore?
	val somethingMore = ::calculator
	result = somethingMore(111, 222, ::sum )
	println("Result = $result ")

	val somethingOnceMore: (Int, Int, (Int, Int) -> Int) -> Int = ::calculator
	result = somethingMore(111, 222, ::sum )
	println("Result = $result ")
}

//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________

fun main() {
	println("\nFunction: playWithCalculator")
	playWithCalculator()

	println("\nFunction: playWithChooseSteps")
	playWithChooseSteps()

	println("\nFunction: playWithCalculatorAgain")
	playWithCalculatorAgain()

	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
}


/*
https://codebunk.com/b/4901100677322/
https://codebunk.com/b/4901100677322/
*/



/*
// Compiling Kotlin Code
kotlinc 01KotlinFundamentals.kt -include-runtime -d fundamentals.jar

// Running Jar File
java -jar fundamentals.jar
*/

package learnKotlin

//_______________________________________________________

fun <T> joinToString(
	collection: Collection<T>,
	separator: String,
	prefix: String,
	postfix: String
) : String {

	val result = StringBuilder( prefix )

	for( (index, element) in collection.withIndex() ) {
		if ( index > 0 ) result.append( separator )
		result.append( element )
	}

	result.append( postfix )
	return result.toString()
}

// Compiler Will Generate Following Code For Above Generic Code
//		It Will Sustitute Type Placeholder T With Type T Based On Usage
/*
fun joinToString(
	collection: Collection<Integer>, separator: String, 
	prefix: String, postfix: String) : String {
	val result = StringBuilder( prefix )

	for( (index, element) in collection.withIndex() ) {
		if ( index > 0 ) result.append( separator )
		result.append( element )
	}

	result.append( postfix )
	return result.toString()
}

fun joinToString( collection: Collection<String>, separator: String, 
prefix: String, postfix: String) : String {

	val result = StringBuilder( prefix )

	for( (index, element) in collection.withIndex() ) {
		if ( index > 0 ) result.append( separator )
		result.append( element )
	}

	result.append( postfix )
	return result.toString()
}
*/

fun playWithJointToString() {
	// What Is Type Of list???
	//		ArrayList<Integer>
	val list = listOf( 100, 200, 300, 444 )
	println( list.javaClass )

	println( joinToString( list, " ; ", " ( ", " ) "))
	println( joinToString( list, " -- ", " [ ", " ] "))

	// What Is Type Of list???
	//		ArrayList<String>
	val names = listOf( "Umang", "Vivek", "Mokshin", "Sanskar", "Shubhashish", 
		"Siddhi", "Aishwarya", "Tanmoy", "Anushka", "Sakshi", "Ritika", "Subhrajit" )

	println( names.javaClass )
	println( joinToString( names, " :: ", " [[ ", " ]] "))
}

//_______________________________________________________
// EXTENSION FUNCTIONS
//		To Add Functionality To Existing Types

fun lastChar( data: String ) = data.get( data.length - 1 )

// Extension Function On Type String
//		lastCharacter() Is A Extension Function On Type String
fun String.lastCharacter() = this.get( this.length - 1 )

fun playWithLastCharacter() {
	println( lastChar("Kotlin") )

	var someData = "Good Morning!"
	println( lastChar( someData ) )

	println( "Kotlin".lastCharacter() )
	println( someData.lastCharacter() )
}

//_______________________________________________________
// Practice Code, Moment Done!, Please Raise Your FLAG!!!

fun <T> Collection<T>.joinToStringExtension(
	separator: String,
	prefix: String,
	postfix: String
) : String {

	val result = StringBuilder( prefix )

	for( (index, element) in this.withIndex() ) {
		if ( index > 0 ) result.append( separator )
		result.append( element )
	}

	result.append( postfix )
	return result.toString()
}

fun playWithJointToStringExtesion() {
	val list = listOf( 100, 200, 300, 444 )

	println( list.joinToStringExtension(" ; ", " ( ", " ) "))
	println( list.joinToStringExtension(" -- ", " [ ", " ] "))

	val names = listOf( "Umang", "Vivek", "Mokshin", "Sanskar", "Shubhashish", 
		"Siddhi", "Aishwarya", "Tanmoy", "Anushka", "Sakshi", "Ritika", "Subhrajit" )

	println( names.joinToStringExtension(" :: ", " [[ ", " ]] "))
}


//_______________________________________________________
// Polymorphic Functions
//		Mechanism: Generics
//		Mechanism: Using Default Arugments

// Function With Default Paratmeters
//		Polymorpic Function
fun <T> Collection<T>.joinToStringExtensionDefault(
	separator: String = ", ", // Default Values
	prefix: String = "",
	postfix: String = ""
) : String {

	val result = StringBuilder( prefix )

	for( (index, element) in this.withIndex() ) {
		if ( index > 0 ) result.append( separator )
		result.append( element )
	}

	result.append( postfix )
	return result.toString()
}

fun playWithJointToStringExtesionDefault() {
	val list = listOf( 100, 200, 300, 444 )

	println( list.joinToStringExtensionDefault() )
	println( list.joinToStringExtensionDefault(" ; " ) )
	println( list.joinToStringExtensionDefault(" ; ", " ( "))
	println( list.joinToStringExtensionDefault(" ; ", " ( ", " ) "))

	val names = listOf( "Umang", "Vivek", "Mokshin", "Sanskar", "Shubhashish", 
		"Siddhi", "Aishwarya", "Tanmoy", "Anushka", "Sakshi", "Ritika", "Subhrajit" )

	println( names.joinToStringExtensionDefault( ))
	println( names.joinToStringExtensionDefault(" :: "))
	println( names.joinToStringExtensionDefault(" :: ", " [[ " ))
	println( names.joinToStringExtensionDefault(" :: ", " [[ ", " ]] "))
}


//_______________________________________________________
// Creating Better API By Using Existing Function
fun Collection<String>.join(
	separator: String = ", ", // Default Values
	prefix: String = "",
	postfix: String = ""
) = joinToStringExtensionDefault( separator, prefix, postfix )


fun playWithJoinString() {
	// val list = listOf( 100, 200, 300, 444 )

	// println( list.join() )
	// println( list.join(" ; " ) )
	// println( list.join(" ; ", " ( "))
	// println( list.join(" ; ", " ( ", " ) "))

	val names = listOf( "Umang", "Vivek", "Mokshin", "Sanskar", "Shubhashish", 
		"Siddhi", "Aishwarya", "Tanmoy", "Anushka", "Sakshi", "Ritika", "Subhrajit" )

	println( names.join( ))
	println( names.join(" :: "))
	println( names.join(" :: ", " [[ " ))
	println( names.join(" :: ", " [[ ", " ]] "))
}

//_______________________________________________________
// EXTENSION PROPERTIES

// Extension Property On Type String
//		lastChar Is IMMUTABLE Extension Property On Type String
val String.lastChar: Char
	get() = get( length - 1 )
	// get() = this.get( this.length - 1 )

// Extension Property On Type StringBuilder
//		lastChar Is MUTABLE Extension Property On Type StringBuilder
var StringBuilder.lastChar: Char
	get() {
		println("Getter Called...")
		return get( length - 1 )
		// return this.get( this.length - 1 )
	}

	set( value: Char ) {
		println("Setter Called...")
		this.setCharAt( length - 1, value )
		// this.setCharAt( this.length - 1, value )
	}

fun playWithExtensionProperties() {
	var character = "Welcome To India!".lastChar
	println( character )

	character = "Ding DOng#".lastChar
	println( character )

	var stringBuilt = StringBuilder("Welcome!!!")
	character = stringBuilt.lastChar
	println( character )

	stringBuilt = StringBuilder("Ding Dong#")
	character = stringBuilt.lastChar
	println( character )
	stringBuilt.lastChar = '$'
	character = stringBuilt.lastChar
	println( character )

}

//_______________________________________________________
// In Kotlin
//		By Default
//			Return Type Of Function Is Unit
//			And It Returns Unit Value Of Unit Type

// Following Both Functions Are Eqivalent
fun doSomething() : Unit {
	println("How are you doing?")
}

fun doSomethingAgain() {
	println("How are you doing?")
}

fun playWithDoSomething() {
	var result = doSomething()
	println( result )

	result = doSomethingAgain()
	println( result )
}

// Function: playWithDoSomething
// How are you doing?
// kotlin.Unit
// How are you doing?
// kotlin.Unit


//_______________________________________________________

fun moveTowardsZero( start: Int ) : Int {
	// Local Function
	//		Function Defined Inside Function
	fun moveForward( start: Int ) = start + 1
	fun moveBackward( start: Int ): Int {
		return start - 1
	}

	return if ( start > 0 ) moveBackward( start ) else moveForward( start )
}

fun plaWithMoveTowardsZero() {
	println( moveTowardsZero( 10 ) )
	println( moveTowardsZero( -10 ) )
}

//_______________________________________________________

class User( val id: Int, val name: String, val address: String )

fun saveUser( user: User ) {
	// Validation: Valid User
	if ( user.name.isEmpty() ) {
		throw IllegalArgumentException("User: ${user.id} Name Empty")
	}

	if ( user.address.isEmpty() ) {
		throw IllegalArgumentException("User: ${user.id} Address Empty")
	}

	// Logic For Saving User...
	println("Saving User... ${user.id}")
}

fun playWithSaveUser() {
	val gabbar = User( 420, "Gabbar Singh", "Ramgarh" )
	val basanti = User( 100, "Basanti Gulati", "Ramgarh")

	saveUser( gabbar )
	saveUser( basanti )
}


//_______________________________________________________

// class User( val id: Int, val name: String, val address: String )

fun saveUserBetter( user: User ) {
	// Validation: Valid User
	// Local Function
	fun validate( user: User, value: String, fieldName: String ) {
		if ( value.isEmpty() ) {
			throw IllegalArgumentException("User: ${user.id} $fieldName Empty")
		}		
	}

	validate( user, user.name, "Name" )
	validate( user, user.address, "Address" )

	// Logic For Saving User...
	println("Saving User... ${user.id}")
}

fun playWithSaveUserBetter() {
	val gabbar = User( 420, "Gabbar Singh", "Ramgarh" )
	val basanti = User( 100, "Basanti Gulati", "Ramgarh")

	saveUser( gabbar )
	saveUser( basanti )
}

//_______________________________________________________

// class User( val id: Int, val name: String, val address: String )

fun saveUserBetterAgain( user: User ) { // Enclosing Context
	// Validation: Valid User
	// Local Function
	//		Can Capture Enclosing Function Context
	//		Enclosed Context Can Capture Enclosing Context
	fun validate( value: String, fieldName: String ) { // Enclosed Context
		if ( value.isEmpty() ) {
			throw IllegalArgumentException("User: ${user.id} $fieldName Empty")
		}		
	}

	validate( user.name, "Name" )
	validate( user.address, "Address" )

	// Logic For Saving User...
	println("Saving User... ${user.id}")
}

fun playWithSaveUserBetterAgain() {
	val gabbar = User( 420, "Gabbar Singh", "Ramgarh" )
	val basanti = User( 100, "Basanti Gulati", "Ramgarh")

	saveUser( gabbar )
	saveUser( basanti )
}

//_______________________________________________________

// class User( val id: Int, val name: String, val address: String )

// BEST DESIGN
fun User.save() { // Enclosing Context
	// Validation: Valid User
	// Local Function
	//		Can Capture Enclosing Function Context
	//		Enclosed Context Can Capture Enclosing Context
	val user = this
	fun validate( value: String, fieldName: String ) { // Enclosed Context
		if ( value.isEmpty() ) {
			throw IllegalArgumentException("User: ${user.id} $fieldName Empty")
		}		
	}

	validate( user.name, "Name" )
	validate( user.address, "Address" )

	// Logic For Saving User...
	println("Saving User... ${user.id}")
}

fun playWithSaveUserExtensionFunction() {
	val gabbar = User( 420, "Gabbar Singh", "Ramgarh" )
	val basanti = User( 100, "Basanti Gulati", "Ramgarh")

	gabbar.save()
	basanti.save()
}

//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
// Practice Code, Moment Done!, Please Raise Your FLAG!!!

fun main() {
	println("\nFunction: playWithJointToString")
	playWithJointToString()

	println("\nFunction: playWithLastCharacter")
	playWithLastCharacter()

	println("\nFunction: playWithJointToStringExtesion")
	playWithJointToStringExtesion()

	println("\nFunction: playWithJointToStringExtesionDefault")
	playWithJointToStringExtesionDefault()

	println("\nFunction: playWithJoinString")
	playWithJoinString()

	println("\nFunction: playWithExtensionProperties")
	playWithExtensionProperties()

	println("\nFunction: playWithDoSomething")
	playWithDoSomething()

	println("\nFunction: plaWithMoveTowardsZero")
	plaWithMoveTowardsZero()

	println("\nFunction:playWithSaveUser ")
	playWithSaveUser()

	println("\nFunction: playWithSaveUserBetter")
	playWithSaveUserBetter()

	println("\nFunction: playWithSaveUserBetterAgain")
	playWithSaveUserBetterAgain()

	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
}

/*
https://codebunk.com/b/4901100677322/
https://codebunk.com/b/4901100677322/
https://codebunk.com/b/4901100677322/
*/

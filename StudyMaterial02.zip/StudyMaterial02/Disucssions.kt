
______________________________________________________

Write Following sum Function In C

DESIGN 01
	int sum( int a, int b ) {
		return a + b;
	}	

______________________________________________________

Write Following sum Function In C
	1. It Returns Valid Arithmatic Sum
	2. Or Prints Not Able Calculate Sum For Given Values

	int sum( int a, int b ) {

	}


DESIGN 02

	int sum( int a, int b ) {

		if a, b > INT_MAX || a, b < INT_MIN {

		else {

		int result = a + b;

		if result > INT_MAX || result < INT_MIN {
			printf("Cant Calculate Sum For Given Values")
		} else {
			return result
		}
	}


DESIGN 03
	int sum( int a, int b ) {
		long result = (long)a + (long) b;

		if result > INT_MAX || result < INT_MIN {
			printf("Cant Calculate Sum For Given Values")
		} else {
			return result
		}
	}


DESIGN 04
	int sum( int a, int b ) {
		long a1 = (long) a;
		long b1 = (long) b;

		if a1 + b1 != a + b
			printf("Cant Calculate Sum For Given Values")
		} else {
			return result
		}
	}

DESIGN 05
	int sum( int a, int b ) {
		if a > INT_MAX - b || a < INT_MIN - b 
			printf("Cant Calculate Sum For Given Values")
		} else {

			return a + b
		}
	}

______________________________________________________

https://github.com/amarjitlife/HSBCAug2024
https://github.com/amarjitlife/HSBCAug2024
https://github.com/amarjitlife/HSBCAug2024

______________________________________________________
______________________________________________________
______________________________________________________
______________________________________________________

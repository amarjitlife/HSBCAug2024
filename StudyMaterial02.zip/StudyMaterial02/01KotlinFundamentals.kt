
/*
// Compiling Kotlin Code
kotlinc 01KotlinFundamentals.kt -include-runtime -d fundamentals.jar

// Running Jar File
java -jar fundamentals.jar
*/

package learnKotlin

import java.util.Random
import java.util.TreeMap

// Function
//		Taking No Arguments
//		It Return Unit Value
fun helloWorld() {
	println("Hello World!!!")
}

//___________________________________________________

// Expression
//		It's A Statement With Return Value

// In C/C++/Java
//		if-else Construct Is A Statement

// In Kotlin
//		if-else Construct Is An Expression

// Functon
//		Takes 2 Arguments of Int Type
//		Return Value Of Int Type
fun max(a: Int, b: Int) : Int {
	// if-else Is An Expression
	// return if (a > b) a else b
	/* C/C++/Java Style
	if (a > b) 
		return a 
	else 
		return b
	*/
	return if (a > b) a else b
}

fun maximum(a: Int, b: Int) = if (a > b) a else b

fun playWithMax() {
	var result: Int

	result = max( -900, 900 )
	println("Result = $result ");

	result = max( 999, 900 )
	println("Result = $result ")

	result = maximum( -900, 900 )
	println("Result = $result ");

	result = maximum( 999, 900 )
	println("Result = $result ")
}

//_______________________________________________________
// Practice Code, Moment Done!, Please Raise Your FLAG!!!

// DESIGN PRICIPLE
//		Designed Towards Expressiveness and Concise
//		Designed As Static Language
//		100% Compatibility With Java
//		Multiple Platform Language

// For Person Class
// Kotlin Compiler Will Generate Following Things
//		1. It Will Generate Constructor
//				Memberwise Initialiser
///		2. For Each Member Property Member Variable Will Be Generated
//		3. For Immutable Property Declared With val e.g. name
//				Getter Will Be Generated
//		4. For Mutable Property Declared With var e.g. isMarried
//				Getter and Setter Will Be Generated

class Person( val name: String,  var isMarried: Boolean )

fun playWithPerson() {
	val gabbar = Person("Gabbar Singh", false)
	println( gabbar.name )			//gabbar.getName()
	println( gabbar.isMarried )		//gabbar.getIsMarried()

	// gabbar.name = "Gabbar Singh Daku"
	gabbar.isMarried = true  		//gabbar.setIsMarried( true )
	println( gabbar.name )			//gabbar.getName()
	println( gabbar.isMarried )		//gabbar.getIsMarried()

	val basanti = Person("Basanti", false)
	println( basanti.name )
	println( basanti.isMarried )
}

//_______________________________________________________
// Practice Code, Moment Done!, Please Raise Your FLAG!!!

// For Rectangle Class
// Kotlin Compiler Will Generate Following Things
//		1. It Will Generate Constructor
//				Memberwise Initialiser With Two Arguments
///		2. For Each Member Property Generated Member Variable
//		3. For Immutable Property Declared With val e.g. height, width
//				Getter Will Be Generated
//		4. For Imutable Property Declared With val With Custom Getter e.g. isSqaure
//				Getter Will NOT BE Generated

// import java.util.Random

class Rectangle(val height: Int, val width: Int) {
	val isSquare: Boolean
		get() { // Custom Getter
			return height == width
		}
}

fun playWithRectangle() {
	val rectangle1 = Rectangle( 100, 200 )
	println( rectangle1.height )
	println( rectangle1.width )
	println( rectangle1.isSquare )

	val rectangle2 = Rectangle( 333, 333 )
	println( rectangle2.height )
	println( rectangle2.width )
	println( rectangle2.isSquare )
}

fun playWithRectangleAgain() {
	val random = Random()
	val rectangle1 = Rectangle( random.nextInt(), random.nextInt() )
	println( rectangle1.height )
	println( rectangle1.width )
	println( rectangle1.isSquare )

	val rectangle2 = Rectangle( random.nextInt(), random.nextInt() )
	println( rectangle2.height )
	println( rectangle2.width )
	println( rectangle2.isSquare )
}

//_______________________________________________________
// Practice Code, Moment Done!, Please Raise Your FLAG!!!

enum class Colour {
	RED, GREEN, BLUE
}

enum class ColourAgain(val r: Int, val g: Int, val b: Int) {
	RED(255, 0, 0), GREEN(0, 255, 0), BLUE(0, 0, 255)
}

fun playWithColour() {
	println( Colour.RED )
	println( Colour.GREEN )
	println( Colour.BLUE ) 

	println( ColourAgain.RED )
	println( ColourAgain.GREEN )
	println( ColourAgain.BLUE ) 	

	println( ColourAgain.RED.r )
	println( ColourAgain.RED.g )
	println( ColourAgain.RED.b )

	println( ColourAgain.GREEN.r )
	println( ColourAgain.GREEN.g )
	println( ColourAgain.GREEN.b )
}

//_______________________________________________________
// Practice Code, Moment Done!, Please Raise Your FLAG!!!

enum class Color( val r: Int, val g: Int, val b: Int ) {
	RED(255, 0, 0), GREEN(0, 255, 0), BLUE(0, 0, 255),
	YELLOW( 100, 100, 90 ), PINK( 50, 50, 50 ), ORANGE( 70, 70, 70 )
}

// In C/C++/Java
//		switch Construct Is A Statement

// In Kotlin
//		when Construct Is An Expression
//		when Is Similar To switch 
//		break Is Implicit In when Expression Branches

// error: return type mismatch: expected 'kotlin.Unit', actual 'kotlin.String
// fun getColorName( color: Color ) {

// error: 'when' expression must be exhaustive. 
//		Add the 'YELLOW' branch 
//		or an 'else' branch.

// DESIGN PRACTICE
//		Always Prefer Exhaustive Cases Over Else Branch
//		Else Branch Should Be Last Choice To Use

fun getColorName( color: Color ) : String {
	// C/C++/Java Style	
	// when( color ) {
	// 	Color.RED 	-> return "Red Color"
	// 	Color.GREEN -> return "Green Color"
	// 	Color.BLUE  -> return "Blue Color"
	// }

	// Kotlin Style
	return when( color ) {
		Color.RED 		-> "Red Color"
		Color.GREEN 	-> "Green Color"
		Color.BLUE  	-> "Blue Color"
		Color.YELLOW 	-> "Yellow Color"
		Color.PINK 		-> "Pink Color"
		Color.ORANGE 	-> "Orange Color"
		// else 		-> "Unknown Color" 
	}
}

fun getColorNameAgain( color: Color ) : String {
	// Kotlin Style
	return when( color ) {
		Color.RED 		-> "Red Color"
		Color.GREEN 	-> "Green Color"
		Color.BLUE  	-> "Blue Color"
		Color.YELLOW 	-> "Yellow Color"
		Color.PINK 		-> "Pink Color"
		// Avoid else Branches Rather Cover Call Cases
		else -> "Unknown Color"
	}
}

fun getColorNameOnceAgain( color: Color ) = when( color ) {
		Color.RED 		-> "Red Color"
		Color.GREEN 	-> "Green Color"
		Color.BLUE  	-> "Blue Color"
		Color.YELLOW 	-> "Yellow Color"
		Color.PINK 		-> "Pink Color"
		Color.ORANGE 	-> "Orange Color"
}

fun playWithColorNames() {
	println( getColorName( Color.RED ) )
	println( getColorName( Color.GREEN ) )
	println( getColorName( Color.BLUE ) )

	println( getColorNameAgain( Color.RED ) )
	println( getColorNameAgain( Color.GREEN ) )
	println( getColorNameAgain( Color.BLUE ) )

	println( getColorNameOnceAgain( Color.RED ) )
	println( getColorNameOnceAgain( Color.GREEN ) )
	println( getColorNameOnceAgain( Color.BLUE ) )
}

//_______________________________________________________
// Practice Code, Moment Done!, Please Raise Your FLAG!!!

fun getColorNature( color: Color ) : String {
	return when( color ) {
		Color.RED, Color.ORANGE  -> "Warm Color"
		Color.YELLOW, Color.BLUE -> "Neutral Color"
		Color.GREEN, Color.PINK  -> "Cold Color"
	}
}

fun playWithColorNature() {
	println( getColorNature( Color.RED ) )
	println( getColorNature( Color.YELLOW ) )
	println( getColorNature( Color.BLUE ) )
	println( getColorNature( Color.GREEN ) )
	println( getColorNature( Color.PINK ) )
}

//_______________________________________________________

// error: return type mismatch: expected 'kotlin.Unit', actual 'learnKotlin.Color'.
// fun mixColors( c1: Color, c2: Color ) {

fun mixColors( c1: Color, c2: Color ): Color {
	// when ( Expression ) {}
	//		Expression Can Be Kotlin Object Of Any Type
	return when( setOf( c1, c2) ) {
		setOf( Color.RED, Color.YELLOW ) -> Color.ORANGE
		setOf( Color.YELLOW, Color.BLUE) -> Color.GREEN
		else -> throw Exception("Unknown Color")
	}
}

// BETTER DESIGN
//		Exceptions Are Not That Exceptional Such That It Breaks Your Design
/*
fun mixColorsAgain( c1: Color, c2: Color ): Color {
	return when( setOf( c1, c2) ) {
		setOf( Color.RED, Color.YELLOW ) -> Color.ORANGE
		setOf( Color.YELLOW, Color.BLUE) -> Color.GREEN
		// else -> throw Exception("Unknown Color")
		else -> Color.UNKNOWN
	}
}
*/

fun playWithColorMixing() {
	println( mixColors( Color.RED, Color.YELLOW ) )
	println( mixColors( Color.YELLOW, Color.RED ) )
	println( mixColors( Color.BLUE, Color.YELLOW ) )
	// println( mixColors( Color.RED, Color.GREEN ) )
}

//_______________________________________________________

interface Expr

class Num( val value: Int ) : Expr
class Sum( val left: Expr, val right: Expr ) : Expr

fun eval( e: Expr ) : Int {
	// What e Type?
	//		Expr
	if ( e is Num ) {	// Smart Type Casting	
	// What e Type?
	//		Num
		return e.value
	}

	// What e Type?
	//		Expr
	if ( e is Sum ) {
	// What e Type?
	//		Sum
		return eval( e.left ) + eval( e.right )
	}

	throw IllegalArgumentException("Unknown Arguments")
}

fun playWithEval() {
	// 100 + 200
	println( eval( Sum( Num(100), Num( 200) ) ) )
	// (  100 + 200 ) + 99
	println( eval( Sum( Sum( Num(100), Num(200)), Num(99) ) ) )
}

//_______________________________________________________

// interface Expr
// class Num( val value: Int ) : Expr
// class Sum( val left: Expr, val right: Expr ) : Expr

fun evalAgain( e: Expr ) : Int {
	return if ( e is Num ) {	// Smart Type Casting	
		e.value
	} else if ( e is Sum ) {
		evalAgain( e.left ) + evalAgain( e.right )
	} else {
		throw IllegalArgumentException("Unknown Arguments")
	}
}


fun evalOnceAgain( e: Expr ) : Int = if ( e is Num ) {		
		e.value
	} else if ( e is Sum ) {
		evalOnceAgain( e.left ) + evalOnceAgain( e.right )
	} else {
		throw IllegalArgumentException("Unknown Arguments")
}


fun playWithEvalAgain() {
	// 100 + 200
	println( evalAgain( Sum( Num(100), Num( 200) ) ) )
	// (  100 + 200 ) + 99
	println( evalAgain( Sum( Sum( Num(100), Num(200)), Num(99) ) ) )

	println( evalOnceAgain( Sum( Num(100), Num( 200) ) ) )
	println( evalOnceAgain( Sum( Sum( Num(100), Num(200)), Num(99) ) ) )
}

//_______________________________________________________

// interface Expr
// class Num( val value: Int ) : Expr
// class Sum( val left: Expr, val right: Expr ) : Expr

fun evaluate( e: Expr ) : Int = when( e ) {
	is Num 	-> e.value
	is Sum 	-> evaluate( e.left ) + evaluate( e.right )
	else 	-> throw IllegalArgumentException("Unknown Arguments")
}

fun playWithEvalulate() {
	// 100 + 200
	println( evaluate( Sum( Num(100), Num( 200) ) ) )
	// (  100 + 200 ) + 99
	println( evaluate( Sum( Sum( Num(100), Num(200)), Num(99) ) ) )
}

//_______________________________________________________

// error: type checking has run into a recursive problem. 
// 		Easiest workaround: specify the types of your declarations explicitly

fun evaluateAgain( e: Expr) : Int  = when( e ) {
	is Num 	-> e.value
	is Sum 	-> evaluateAgain( e.left ) + evaluateAgain( e.right )
	else 	-> throw IllegalArgumentException("Unknown Arguments")
}

fun playWithEvalulateAgain() {
	// 100 + 200
	println( evaluateAgain( Sum( Num(100), Num( 200) ) ) )
	// (  100 + 200 ) + 99
	println( evaluateAgain( Sum( Sum( Num(100), Num(200)), Num(99) ) ) )
}

//_______________________________________________________

fun fizzBuzz( number: Int ) = when { // Pattern Matching
	number % 15 == 0 -> "FizzBuzz "
	number %  3 == 0 -> "Fizz "
	number %  5 == 0 -> "Buzz "
	else -> "$number "
}

fun playWithFizzBuzz() {
	for ( number in 1..100 ) {
		print( fizzBuzz( number ) )
	}

	for ( number in 100 downTo 1 step 2 ) {
		print( fizzBuzz( number ) )		
	}
}

//_______________________________________________________

// import java.util.TreeMap

fun playWithTreeMaps() {
	//In Kotlin
	//		Using Java Collections APIs Directly In Kotlin
	val binaryRepresentation = TreeMap<Char, String>()
	// In Java
	//		final TreeMap<Char, String> binaryRepresentation = 
	//				new TreeMap<Char, String>()

	for ( character in 'A'..'F' ) {
		val binary = Integer.toBinaryString( character.code ) 
		binaryRepresentation[ character ] = binary
	}

	for ( ( letter, binary )  in binaryRepresentation ) {
		println(" $letter = $binary")
	}
}

//_______________________________________________________

fun isLetter( character : Char )  = character in 'a'..'z' || character in 'A'..'Z'
fun isNotDigit( character: Char ) = character !in '0'..'9'

fun recognise( character : Char ) = when( character ) {
	in '0'..'9' 				-> "It's Digit"
	in 'a'..'z', in 'A'..'Z'	-> "It's Letter"
	else 						-> "Unknown Character!"
}

//_______________________________________________________

fun playWithCollectionsInKotlin() {
	val set 	= hashSetOf( 11, 77, 99, 88 )
	val list 	= arrayListOf( 11, 77, 99, 88 )
	val map 	= hashMapOf( 1 to "One", 10 to "Ten", 50 to "Fifty" )

	println( set.javaClass )
	println( list.javaClass )
	println( map.javaClass )

	var strings = listOf( "First", "Second", "Third", "One" )
	println( strings.last() )
	println( strings.javaClass )

	val numnbers = setOf( 11, 88, 88, 99, 11 )
	println( numnbers.javaClass )
	println( numnbers.maxOrNull() )
}
// class java.util.HashSet
// class java.util.ArrayList
// class java.util.HashMap
// One
// class java.util.Arrays$ArrayList
// class java.util.LinkedHashSet
// 99

//_______________________________________________________

fun playWithDataTypes() {
	// Following Both Lines Are Equivalent
	//	1. Type Inferrencing From RHS Value/Expression
	//	2. Type Binding Happens With LHS
	//			Binds The Infered Type
	val some  = 90 // Default Inferred Type Will Be Int
	val some1: Int = 90 
	println( some )
	println( some1 )

	// some = "Good Noon!!!"
	// Following Both Lines Are Equivalent
	val something = 99.99 // Default Inferred Type Will Be Double
	val somethingAgain: Double = 99.99

	println( something )
	println( somethingAgain )

	val something1: Float = 99.99F //Explicitly Annotating Type Float
	println( something1 ) 

	// error: initializer type mismatch: expected 'kotlin.Float', actual 'kotlin.Double'.
	// val something2: Float = 99.99 
	// println( something2 ) 

	val something2 = 99.99F //Explicitly Annotating Type Float
	println( something2 ) 

	// Following Both Lines Are Equivalent
	val greeting = "Good Morning!!!"
	val greetingAgain: String = "Good Morning!!!"
	println( greeting )
	println( greetingAgain )
}

//_______________________________________________________

fun maximumAgain0(a: Int, b: Int) = if (a > b) a else "Oyee Hoyeee!!!"

fun maximumAgain1(a: Int, b: Int) : Any = if (a > b) a else "Oyee Hoyeee!!!"

//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
// Practice Code, Moment Done!, Please Raise Your FLAG!!!

fun main() {
	println("\nFunction: helloWorld")
	helloWorld()

	println("\nFunction: playWithMax")
	playWithMax()

	println("\nFunction: playWithPerson")
	playWithPerson()

	println("\nFunction: playWithRectangle")
	playWithRectangle()

	println("\nFunction: playWithRectangleAgain")
	playWithRectangleAgain()

	println("\nFunction: playWithColour")
	playWithColour()

	println("\nFunction: playWithColorNames")
	playWithColorNames()

	println("\nFunction: playWithColorNature")
	playWithColorNature()

	println("\nFunction: playWithColorMixing")
	playWithColorMixing()

	println("\nFunction: playWithEval")
	playWithEval()

	println("\nFunction: playWithEvalAgain")
	playWithEvalAgain()

	println("\nFunction: playWithEvalulate")
	playWithEvalulate()

	println("\nFunction: playWithFizzBuzz")
	playWithFizzBuzz()

	println("\nFunction: playWithTreeMaps")
	playWithTreeMaps()

	println("\nFunction: playWithCollectionsInKotlin")
	playWithCollectionsInKotlin()

	println("\nFunction: playWithDataTypes")
	playWithDataTypes()

	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
}

// https://codebunk.com/b/4901100677322/
// https://codebunk.com/b/4901100677322/
// https://codebunk.com/b/4901100677322/

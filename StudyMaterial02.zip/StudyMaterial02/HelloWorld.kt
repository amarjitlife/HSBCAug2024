
/*
// Compiling Kotlin Code
kotlinc HelloWorld.kt -include-runtime -d hello.jar

// Running Jar File
java -jar hello.jar
*/

package learnKotlin

fun main() {
	println("Hello World!!!")
}

/*
// Environment Setup
https://github.com/JetBrains/kotlin/releases/tag/v2.0.10
https://github.com/JetBrains/kotlin/releases/tag/v2.0.10
https://github.com/JetBrains/kotlin/releases/tag/v2.0.10

1. Download Kotlin Compiler
	kotlin-compiler-2.0.10.zip
	79.9 MB

2. Copy 	kotlin-compiler-2.0.10.zip
		YOUR_PATH/Documents/Softwares

3. Unzip 
	kotlin-compiler-2.0.10.zip

4. Add Following in PATH Variable
		YOUR_PATH/Documents/Softwares/kotlinc/bin
*/

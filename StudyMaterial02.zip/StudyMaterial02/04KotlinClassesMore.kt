/*
// Compiling Kotlin Code
kotlinc 04KotlinClassesMore.kt -include-runtime -d classes.jar

// Running Jar File
java -jar classes.jar
*/

package learnKotlin

//_______________________________________________________
// Practice Code, Moment Done!, Please Raise Your FLAG!!!

data class Grade( val letter: Char, val points: Double, val credits: Double)

// Following Both Lines Are Same
			// Primary Constructor
// class Person( val firstName: String, val lastName: String = "")

// open class Person constructor( 
// 	open val firstName: String, 
// 	open val lastName: String = "") {
// 	fun fullName() = "$firstName $lastName"
// }


// error: 'firstName' hides member of supertype 'Person' and needs an 'override' modifier.
// error: 'lastName' hides member of supertype 'Person' and needs an 'override' modifier.
// class Student( 
// 	override val firstName: String, 
// 	override val lastName: String, 
// 	var grades: MutableList<Grade> = mutableListOf<Grade>()
// ):  Person( firstName, lastName ) {

// 	fun recordGrades( grade: Grade ) {
// 		grades.add( grade )
// 	}
// }

open class Person constructor( val firstName: String, val lastName: String = "") {
	fun fullName() = "$firstName $lastName"
}

open class Student( 
	firstName: String, 
	lastName: String, 
	var grades: MutableList<Grade> = mutableListOf<Grade>()
):  Person( firstName, lastName ) {

	open fun recordGrades( grade: Grade ) {
		grades.add( grade )
	}
}

fun playWithClassesAndObjects() {
	val gabbar = Person( firstName = "Gabbar", lastName = "Singh" )
	val alice = Student( firstName = "Alice", lastName = "Carol" )

	println( gabbar.fullName() )
	println( alice.fullName() )

	val history = Grade( letter = 'B', points = 9.0, credits = 3.0 )
	alice.recordGrades( history )
}


//_______________________________________________________

open class BandMember( firstName: String, lastName: String ) : Student(firstName, lastName) {
	// Property Have 3 Things Associated With It: 
	//		1. Member Variable
	//		2. Getter
	//		3. Setter
	// error: 'minimumPracticeTime' in 'BandMember' is final and cannot be overridden
	open val minimumPracticeTime: Int
		get() { return 2 }
}

class TablaPlayer( firstName: String, lastName: String ) : BandMember(firstName, lastName) {
	override val minimumPracticeTime: Int
		get() { return super.minimumPracticeTime * 2 }
}

fun playWithTypeChecks() {
	val zakirHusaain: Person = TablaPlayer( firstName = "Zakir", lastName = "Husain" )
	var classMonitor = Student( firstName = "Visawnath", lastName = "Anand" )

	println( zakirHusaain.fullName() )
	println( classMonitor.fullName() )

	println( zakirHusaain is TablaPlayer )
	println( zakirHusaain is BandMember )
	println( zakirHusaain is Student )
	println( zakirHusaain is Person )

	println( classMonitor is TablaPlayer )
	println( classMonitor is BandMember )
	println( classMonitor is Student )
	println( classMonitor is Person )

	// println( zakirHusaain.minimumPracticeTime )
	println( (zakirHusaain as BandMember).minimumPracticeTime )
}

//_______________________________________________________

// FUNCTION OVERLOADING

// Polymorphism: Taking Multiple Forms
// How To Achieve Polymorphism Using Mechanism
// What Is Polymorphism?

// DEFINITION DRIVEN DESIGN
// 		Some Code Block: C
// 			Derivative Of C w.r.t. Time Is Zero
// 		Hence Invariant Code C

// Mechanism: Function Overloading
// 		C = Function Name

fun afterClassroomActivity( student: Student ) : String {
	return "Goes Home!"
}

fun afterClassroomActivity( student: BandMember ) : String {
	return "Goes To Practice!!!"
}

fun playWithAfterClassroomActivityFunctions() {
	val zakirHusaain = TablaPlayer( firstName = "Zakir", lastName = "Husain" )
	val gabbar = Student( firstName = "Gabbar ", lastName = "Singh" )

	println( afterClassroomActivity( zakirHusaain ) )
	println( afterClassroomActivity( gabbar ))
}

//_______________________________________________________


// POLYMORPHISM DESIGN PRACTICES

// Polymorphish Mechanisms Preference Order
//  0. Generics Functions
//  1. Function With Default Arguments
// 			Hence Prefer Constructors With Default Arguments 
//				Rather Than Overloading Constructor
//  2. Higher Order Functions
// 			Passing and/or Returning Behvaiour From Behvaiour
//  3. Class/Type Is Polymophic
//  4. Function Overloding

//_______________________________________________________

class Athlete( firstName: String, lastName: String = "" ) : Student( firstName, lastName ) {
	val failedClasses = mutableListOf<Grade>()

	override fun recordGrades( grade: Grade ) {
		super.recordGrades(grade)

		if ( grade.letter == 'F' ) {
			failedClasses.add( grade )
		}
	}

	val isEligible: Boolean
		get() = failedClasses.size < 3
}

fun playWithAthelete() {
	val gabbar = Athlete( firstName = "Gabbar", lastName = "Singh" )

	val history = Grade( letter = 'B', points = 9.0, credits = 3.0 )
	val shooting = Grade( letter = 'A', points = 10.0, credits = 4.0 )
	val looting = Grade( letter = 'B', points = 9.0, credits = 3.0 )

	gabbar.recordGrades( history )
	gabbar.recordGrades( shooting )
	gabbar.recordGrades( looting )

	// Some Single Line Logic Can Be Written In prinln String Interpolation Using { }
	println("${gabbar.fullName() } is ${if (gabbar.isEligible) "Eligible" else "InEligible"}" )
}

//_______________________________________________________


// Abstract Type = { Operation, Range }
//		Operation = { dummyFunction }
//		Range = ϕ
interface DummyInterface {
	fun dummyFunction()
}


// Abstract Class
//		Having Atleast One Abstract Method
//			Abstract Method Have Only Signature
abstract class Mammal( val birthDate: String ) {
	abstract fun consumeFood()
	abstract fun doWork()
	fun doMagic() = println("Doing Magic")
}

// In Case Child Class Doesn't Provide Implementation Of Atleast One Abstract Method
// 		Than Either Class Should Be Abstract Or Provide Implementation
// abstract class Human(birthDate: String) : Mammal( birthDate ) {

// Concrete Classes
// 		Which Are Not Abstract
// 		i.e. Which Provides Implementations For All Abstract Functions

class Human(birthDate: String) : Mammal( birthDate ) {
	override fun consumeFood() {
		println("Consuming Food....")
	}

	override fun doWork() {
		println("Do Work!!!")
	}

	fun createBirthCertificate() {
		println("Birth Certificate Generated With Date Of Birth: $birthDate")
	}
}

fun playWithMammels() {
 // error: cannot create an instance of an abstract class
 // error: interface DummyInterface does not have constructors
	// val mammel = Mammal("01/01/1955")
	// val dummy = DummyInterface()

	val gabbar = Human( "01/01/1960")
	gabbar.createBirthCertificate()

	gabbar.consumeFood()
	gabbar.doWork()
	gabbar.doMagic()
}

//_______________________________________________________

// DESIGN PRACTICE
//		1. Always Prefer Interfaces Over Abstract Classes
//		2. Always Prefer Abstast Classes Over Concrete Classes
//		3. Concrete Classes Are Last In Design 

//_______________________________________________________

/*
abstract class Shape {
// 	error: property must be initialized or be abstract
	abstract var size: Int
	abstract var color: String

	override fun toString() = "Circle(size=$size, color=$color)"
}
*/

// SECONDARY CONSTRUCTORS
// 	Constructor Overloading!!!

// CONSTRUCTOR DESIGN CHOICES

// 		Either You Define Default Construtor
// 			AND/OR
// 		Design Constructor Delegation
// 			Using this And/Or super
// 			PreCondition: All Properties Coming From Parent Class Should Be Initialised
// 				By Delegating to Parent Class Constructor


// CONSTRUCTOR DESIGN PRACICES
// 		Always Prefer Primary Constructor With Default Arguments
// 				You Will Maintain Only Constructor
// 				You Can Prove Constructor Initialing Object Fully
// 				Rather Than Overloading Use Default Arguments
// 					Compulsary Arguments Should Come Before Default Arguments

// 		For Constructor Overloading Practice
// 				Every Class In Hierarcy Should Have Full Constructor
// /					Full Constructor Initialises All The Properties
// 				All Other Constructors In Same Class
// 					Should Call Full Constructor Within Class
// 				All Full Constructors Within Class Should Call Parent Class Full Constructor

// DESIGN PRINCIPLE
// 		Object Must Follow Relflexive Law
// 			Reflexive Law: For anny non-null reference value x, x.equals(x) should return true.


open class Shape {
// 	error: property must be initialized or be abstract
	// var size: Int  		= 0
	// var color: String 	= "Unknown"
	var size: Int  	
	var color: String 

	// 
	constructor() : this( 0, "Unknown" ) {
		// this.size = 0
		// this.color = "Unknown"
	}

	constructor(size: Int) : this( size, "Unknown") {
		// this.size = 0
		// this.color = "Unknown"
	}

	// Full Constructor
	constructor( size: Int, color: String ) {
		this.size 	= size
		this.color = color
	}

	override fun toString() = "Shape(size=$size, color=$color)"
}

class Circle : Shape {
	var radius: Int

	constructor() : this(0, "Unknown", 0) {
		// this.size = 0
		// this.color = "Unknown"
		// this.radius = 0
	}
	
	constructor( size: Int, color: String ) : this(size, color, 0) {
		// this.size 	= size
		// this.color = color
		// this.radius = 0
	}

	// Full Constructor
	constructor( size: Int, color: String, radius: Int ) : super(size, color) {
		// this.size 	= size
		// this.color = color
		this.radius = 0
	}

	override fun toString() = "Circle(size=$size, color=$color)"
}

fun playWithConstrutors() {
	val shape1 = Shape()
// error: too many arguments for 'public constructor(): learnKotlin/Shape'.
	val shape2 = Shape( 99, "Red")
	println( shape1 )
	println( shape2 )

	val circle1 = Circle()
	val circle2 = Circle( 100, "Blue" )

	println( circle1 )
	println( circle2 )
}

//_______________________________________________________



//______________________________________________________________
// VISIBILITUY MODIFIERS

data class Privilege( val id : Int, val name: String )
open class User( val username: String, private val id: String, protected var age: Int )

class PrivilegedUser(username: String, id: String, age: Int) : User( username, id, age ) {
	private val privileges = mutableListOf<Privilege>()

	fun addPrivilege( privilege: Privilege ) {
		privileges.add( privilege )
	}

	fun hasPrivilege( id: Int ): Boolean {
		return privileges.map( { it.id } ).contains(id)
	}

	fun about(): String = "$username, $age"
}

fun playWithVisibilityModifiers() {
	val gabbar = PrivilegedUser( username = "Gabbar Singh", id = "420", age = 30 )
	val privilege = Privilege( 1, "Uncatchable!")
	gabbar.addPrivilege( privilege )
	println( gabbar.about() )
}


// Kotlin Visibility Modifiers
// ___________________________________________________________________

// Modifiers 			|  	Class Member 		| Top-Level Member
// ___________________________________________________________________
// public (default) 	| Visible everywhere 	| Visible everywhere 
// internal 			| Visible in a module   | Visible in a module
// protected 			| Visiable In SubClasses| NOT APPLICABLE
// private  			| Visible In A Class 	| Visible In File
// ___________________________________________________________________

//_______________________________________________________

class UserAgain( val id: Int, val name: String, val address: String )

// BEST DESIGN
fun UserAgain.save() { // Enclosing Context
	// Local Class
	//		Class Defined Inside Function
	class Human(val id: Int, val firstName: String, val lastName: String) {
		val fullName: String
			get() = "$firstName $lastName"
	}

	val god = Human( 100, "Sachin", "Tendulkar" )
	print( god.fullName )


	// Validation: Valid User
	// Local Function
	//		Can Capture Enclosing Function Context
	//		Enclosed Context Can Capture Enclosing Context
	val user = this
	fun validate( value: String, fieldName: String ) { // Enclosed Context
		if ( value.isEmpty() ) {
			throw IllegalArgumentException("User: ${user.id} $fieldName Empty")
		}		
	}

	validate( user.name, "Name" )
	validate( user.address, "Address" )

	// Logic For Saving User...
	println("Saving User... ${user.id}")

}

fun playWithSaveUserExtensionFunction() {
	val gabbar = UserAgain( 420, "Gabbar Singh", "Ramgarh" )
	val basanti = UserAgain( 100, "Basanti Gulati", "Ramgarh")

	gabbar.save()
	basanti.save()
}

//_______________________________________________________

// In Kotlin Classes Are Nested By Default
// In Java Classes Are Inner By Default

class Car1( val carName: String ) { //Enclosing Context
	var something = "Hello HSBC!!! TSEs!!!"

	fun doSomething() { // Enclosed Context
		println("Something=$something")
	}

	// Nested Class
	//		Class Defined Inside Class
	//		It DOESN'T CATPURE ENCLOSING CONTEXT
	class Engine( val engineName: String ) { // Enclosed Context
		override fun toString(): String {
			// error: unresolved reference 'carName'
			// return "Engine(engineName=$engineName) In Car(carName=$carName)"
			return "Engine(engineName=$engineName)"
		}
	}

	override fun toString() = "Car1(carName=$carName)"
}

fun playWithClassInsideClassNested() {
	val audi = Car1("Audi")
	val v8 = Car1.Engine("V8 Enginer")

	println( audi )
	println( v8 )
}

//_______________________________________________________

class Car2( val carName: String ) { //Enclosing Context
	var something = "Hello HSBC!!! TSEs!!!"

	fun doSomething() { // Enclosed Context
		println("Something=$something")
	}
	// Inner Class
	//		Class Defined Inside Class
	//		It DOES CATPURE ENCLOSING CONTEXT
	inner class Engine( val engineName: String ) { // Enclosed Context
		override fun toString(): String {
			// error: unresolved reference 'carName'
			return "Engine(engineName=$engineName) In Car(carName=$carName)"
			// return "Engine(engineName=$engineName)"
		}
	}

	override fun toString() = "Car1(carName=$carName)"
}

fun playWithClassInsideClassInner() {
	val audi = Car2("Audi")
	val v8 = audi.Engine("V8 Enginer")

	println( audi )
	println( v8 )
}

//_______________________________________________________

class SomeClass {
	// Type/Class Member
	companion object {
		fun doMagic() {
			println("Doing Magic!!!...")
		}

		fun doSomething() {
			println("Doing Something...")
		}
	}
}

fun playWithCompanionObject() {
	SomeClass.doMagic()
	SomeClass.doSomething()
}

//_______________________________________________________

fun getFacebookName( acccontID: Int ) = "FB:$acccontID"

class UserMore private constructor( val nickname: String ) {
	companion object {
		// It Will Bind Members With Type/Class
		// Factory Methods
		//		Following Methods Creates Object
		fun newSubscribingUser( email: String ) : UserMore {
			return UserMore( email.substringBefore('@'))
		}

		fun newFacebookUser( acccontID: Int ) : UserMore {
			return UserMore( getFacebookName( acccontID ) )
		}
	}

	override fun toString() = "UserMore(nickname=$nickname)"
}


fun playWithCompanionObjectMore() {
	val fbUser  = UserMore.newFacebookUser( 999 )
	println( fbUser )

	val subscribingUser = UserMore.newSubscribingUser( "amarjitmca04@gmail.com" )
	println( subscribingUser)
}

//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
// Practice Code, Moment Done!, Please Raise Your FLAG!!!

fun main() {
	println("\nFunction: playWithClassesAndObjects")
	playWithClassesAndObjects()

	println("\nFunction: playWithTypeChecks")
	playWithTypeChecks()

	println("\nFunction: playWithConstrutors")
	playWithConstrutors()

	println("\nFunction: playWithSaveUserExtensionFunction")
	playWithSaveUserExtensionFunction()

	println("\nFunction: playWithClassInsideClassNested")
	playWithClassInsideClassNested()

	println("\nFunction: playWithClassInsideClassInner")
	playWithClassInsideClassInner()

	println("\nFunction: playWithCompanionObject")
	playWithCompanionObject()

	println("\nFunction: playWithCompanionObjectMore")
	playWithCompanionObjectMore()

	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
}


/*
https://codebunk.com/b/4901100677322/
https://codebunk.com/b/4901100677322/
*/

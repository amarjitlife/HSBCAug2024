
package learnKotlin

// DESIGN PRINCIPLE
//		DESIGN TOWARDS ABSTRACT TYPE RATHER THAN TYPE

// DESIGN PRACTICE
//		1. Design Towards Interfaces Rather Than Concrete Classes


interface Superpower {
	fun fly()
	fun saveWorld()
}

class Spiderman : Superpower {
	override fun fly() 		=  println("Fly Like Spiderman!")
	override fun saveWorld() =  println("Save World Like Spiderman!")
}

// open class Spiderman {
// 	open fun fly() 		 =  println("Fly Like Spiderman!")
// 	open fun saveWorld() =  println("Save World Like Spiderman!")
// }

class Superman : Superpower {
	override fun fly() 		 =  println("Fly Like Superman!")
	override fun saveWorld()  =  println("Save World Like Superman!")
}

open class Heman {
	open fun fly() 		 =  println("Fly Like Heman!")
	open fun saveWorld() =  println("Save World Like Heman!")
}

class Wonderwoman : Superpower {
	override fun fly() 		 =  println("Fly Like Wonderwoman!")
	override fun saveWorld()  =  println("Save World Like Wonderwoman!")
}

//_____________________________________________________________
// DESIGN 01: Using Inheritance
// class Human : Spiderman() {
// class Human : Superman() {
class Human : Heman() {
	override fun fly() 		{ super.fly() }
	override fun saveWorld() { super.saveWorld() }
}

//_____________________________________________________________
// DESIGN 02: Using Composition
// class Human : Spiderman() {
// class Human : Superman() {
// class Human : Heman() {
class HumanBetter {
	// var power = Spiderman()
	// var power = Superman()
	var power = Heman()	
	fun fly() 		 { power.fly() }
	fun saveWorld()  { power.saveWorld() }
}


//_____________________________________________________________
// DESIGN 03: Using Composition
//		Composition Is Equivalent To Inheritance
//		It Allows Substraction

// class Human : Spiderman() {
// class Human : Superman() {
// class Human : Heman() {
class HumanBest {
	// var power = Spiderman()
	// var power = Superman()
	// var power = Heman()	
	var power: Superpower? = null
	fun fly() 		 { power?.fly() }
	fun saveWorld()  { power?.saveWorld() }
}

//_____________________________________________________________

fun fullfillDreams() {
	val spider = Spiderman()
	spider.fly()
	spider.saveWorld()

	val hu = Human()
	hu.fly()
	hu.saveWorld()

	println("Human Better...")
	val better = HumanBetter()
	better.fly()
	better.saveWorld()

	println("Human Best...")
	val best = HumanBest()
	best.power = Spiderman()
	best.fly()
	best.saveWorld()

	best.power = Superman()
	best.fly()
	best.saveWorld()

	best.power = Wonderwoman()
	best.fly()
	best.saveWorld()	
}

//_____________________________________________________________

fun main() {
	fullfillDreams()
}

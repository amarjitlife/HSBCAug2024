
#include <stdio.h>

//_______________________________________________________

// int sum( int a, int b ) {
// 	int result = 0;
// 	// Type Safe Code
// 	if  b > 0 && a > INT_MAX - b ||
// 		b < 0 && a < INT_MIN - b {
// 			Can't
// 		} else {
// 			return a + b
// 		}

// }

//_______________________________________________________

typedef struct human_type {
	int id;
	char name[100];
	void (*dance)();
} Human;

void doBhangra() {
	printf("Oyeee Hoyeee Ballleeee Ballleeee!!!!");
}

void doHipHop() {
	printf("Yo Yo!!!!!!");
}

void playWithHuman() {
					// Constuctor
	Human gabbar = { 420, "Gabbar Singh", doBhangra };

	printf("\nID 	: %d", gabbar.id );
	printf("\nName 	: %s", gabbar.name );
	gabbar.dance();
					// Constuctor
	Human basanti = { 100, "Basanti Gulati", doHipHop };
	printf("\nID 	: %d", basanti.id );
	printf("\nName 	: %s", basanti.name );
	basanti.dance();
}

//_______________________________________________________

int sum( int a, int b ) { return a + b; }
int sub( int a, int b ) { return a - b; }
int mul( int a, int b ) { return a * b; }

// Polymorphic Function
//		Mechanism: Passing A Behaviour To Behaviour
int calculator( int a, int b, int (*operation)(int, int) ) {
	return operation(a, b);
}

void playWithCalculator() {
	int a = 40;
	int b = 20;
	int result = 0;

	result = calculator( a, b, sum ); // Configuring calculator As sum
	printf("\n Result : %d", result );

	result = calculator( a, b, sub );  // Configuring calculator As sum
	printf("\n Result : %d", result );

	result = calculator( a, b, mul );  // Configuring calculator As mul 
	printf("\n Result : %d", result );
}

//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________

int main() {
	printf("\nFunction: playWithHuman");
	playWithHuman();

	printf("\nFunction: playWithCalculator");
	playWithCalculator();

	// printf("\nFunction: ");
	// printf("\nFunction: ");
	// printf("\nFunction: ");
	// printf("\nFunction: ");
	// printf("\nFunction: ");
	// printf("\nFunction: ");
	return 0;
}
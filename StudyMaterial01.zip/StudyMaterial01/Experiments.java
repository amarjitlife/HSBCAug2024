
public class Experiments {
	public static void playWithNumbers() {
		System.out.println( 1.0 / 0.0 );
		System.out.println( -1.0 / 0.0 );
		System.out.println( 0.0 / 0.0 ); 
	}

	public static void main(String[] args) {
		System.out.println("\nFunction: playWithNumbers");
		playWithNumbers();

	} 
}


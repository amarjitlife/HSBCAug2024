// Sealed classes and interfaces provide controlled inheritance of your class hierarchies. 
// All direct subclasses of a sealed class are known at compile time. 
// No other subclasses may appear outside the module and package within 
// which the sealed class is defined. 

// The same logic applies to sealed interfaces and their implementations: 
// once a module with a sealed interface is compiled, 
// no new implementations can be created.

// Direct subclasses are classes that immediately inherit from their superclass.
// Indirect subclasses are classes that inherit from more than one level down from their superclass.

// Sealed classes are best used for scenarios when:

// 1. Limited class inheritance is desired: 
// You have a predefined, finite set of subclasses that extend a class, 
// all of which are known at compile time.

// 2. Type-safe design is required: 
// Safety and pattern matching are crucial in your project. 
// Particularly for state management or handling complex conditional logic. 
// For an example, check out Use sealed classes with when expressions.

// 3. Working with closed APIs: 
// You want robust and maintainable public APIs for libraries that ensure that 
// third-party clients use the APIs as intended.

// A sealed class itself is always an abstract class, and as a result, can't be instantiated directly.
//______________________________________________________________

// Create a sealed interface
sealed interface Error

// Create a sealed class that implements sealed interface Error
sealed class IOError(): Error

// Define subclasses that extend sealed class 'IOError'
class FileReadError(val file: File): IOError()
class DatabaseError(val source: DataSource): IOError()

// Create a singleton object implementing the 'Error' sealed interface
object RuntimeError : Error


//______________________________________________________________
// Your Types Or Type System Is A Theorm
// Your Code/Function Is A Proof

// Type System
enum class ErrorSeverity { MINOR, MAJOR, CRITICAL }

sealed class Error(val severity: ErrorSeverity) {
    class FileReadError(val file: File): Error(ErrorSeverity.MAJOR)
    class DatabaseError(val source: DataSource): Error(ErrorSeverity.CRITICAL)
    object RuntimeError : Error(ErrorSeverity.CRITICAL)
    // Additional error types can be added here
}

// Proof
// Function to log errors
fun log(e: Error) = when(e) {
    is Error.FileReadError -> println("Error while reading file ${e.file}")
    is Error.DatabaseError -> println("Error while reading from database ${e.source}")
    Error.RuntimeError -> println("Runtime error")
    // No `else` clause is required because all the cases are covered
}

//______________________________________________________________
// DEFININING STATE MACHINE

sealed class UIState {
    data object Loading : UIState()
    data class Success(val data: String) : UIState()
    data class Error(val exception: Exception) : UIState()
}

fun updateUI(state: UIState) {
    when (state) {
        is UIState.Loading -> showLoadingIndicator()
        is UIState.Success -> showData(state.data)
        is UIState.Error -> showError(state.exception)
    }
}



//___________________________________________________________________

// Java program implementing Singleton class
// with using getInstance() method

// Class 1
// Helper class
class Singleton {
	// Static variable reference of single_instance
	// of type Singleton
	private static Singleton single_instance = null;

	// Declaring a variable of type String
	public String s;

	// Constructor
	// Here we will be creating private constructor
	// restricted to this class itself
	private Singleton() {
		s = "Hello I am a string part of Singleton class";
	}

	// Static method
	// Static method to create instance of Singleton class
	public static synchronized Singleton getInstance() {
		if (single_instance == null)
			single_instance = new Singleton();

		return single_instance;
	}
}

// Class 2
// Main class
class SingletonDemo {
	// Main driver method
	public static void playWithSingleton() {
		// Instantiating Singleton class with variable x
		Singleton x = Singleton.getInstance();

		// Instantiating Singleton class with variable y
		Singleton y = Singleton.getInstance();

		// Instantiating Singleton class with variable z
		Singleton z = Singleton.getInstance();

		// Printing the hash code for above variable as
		// declared
		System.out.println("Hashcode of x is "
						+ x.hashCode());
		System.out.println("Hashcode of y is "
						+ y.hashCode());
		System.out.println("Hashcode of z is "
						+ z.hashCode());

		// Condition check
		if (x == y && y == z) {

			// Print statement
			System.out.println(
				"Three objects point to the same memory location on the heap i.e, to the same object");
		}

		else {
			// Print statement
			System.out.println(
				"Three objects DO NOT point to the same memory location on the heap");
		}
	}
}

//___________________________________________________________________

class NumbersDemo {
	public static void playWithNumbers() {
		System.out.println( 1.0 / 0.0 );
		System.out.println( -1.0 / 0.0 );
		System.out.println( 0.0 / 0.0 ); 
	}
}

//___________________________________________________________________


//_______________________________________________________

// fun sum(a: Int, b: Int) = a + b
// fun sub(a: Int, b: Int) = a - b

// fun calculator( a: Int, b: Int, operation: (Int, Int) -> Int ) : Int {
// 	return operation( a, b )
// }

// fun playWithCalculator() {
// 	val a = 40
// 	val b = 20
// 	var result = 0

// 	result = calculator( a, b, ::sum )
// 	println("Result = $result ")

// 	result = calculator( a, b, ::sub )
// 	println("Result = $result ")

// 	// What Is The Type Of something?
// 	val something: (Int, Int) -> Int = ::sum
// 	result = something( 100, 200 )
// 	println("Result = $result ")
// }

interface Operation {
	int operate(int a, int b);
}

class Sum implements Operation {
	public int operate( int a, int b ) { 
		return a + b;
	}
}

class Sub implements Operation {
	public int operate( int a, int b ) { 
		return a - b;
	}
}

class Calculator {
	//Polymorphic Function
	//		Mechanism: Using Function Overloading
	// public static int calculate( int a, int b, Sum operation ) {
	// 	return operation.operate(a, b);
	// }

	// public static int calculate( int a, int b, Sub operation ) {
	// 	return operation.operate(a, b);
	// }

	//Polymorphic Function
	//		Mechanism: Using Interface Type Argument
	public static int calculate( int a, int b, Operation operation ) {
		return operation.operate(a, b);
	}

	public static void playWithCalculator() {
		int a = 40;
		int b = 20;
		int result = 0;

		result = calculate(a, b, new Sum() );
		System.out.println("Result = " + result);

		result = calculate(a, b, new Sub() );
		System.out.println("Result = " + result);
	}
}

//___________________________________________________________________

class FilterMapDemo {

  public static void playWithFilterMap() {

    List<String> numbers = Arrays.asList("1", "2", "3", "4", "5", "6");
    System.out.println("original list: " + numbers);

    List<Integer> even = numbers.stream()
                                .map( s -> Integer.valueOf(s) )
                                .filter( number -> number % 2 == 0 )
                                .collect(Collectors.toList());

    System.out.println("processed list, only even numbers: " + even);

  }

}

//___________________________________________________________________
//___________________________________________________________________
//___________________________________________________________________
//___________________________________________________________________

public class Experiments {

	public static void main(String[] args) {
		System.out.println("\nFunction: playWithNumbers");
		NumbersDemo.playWithNumbers();

		System.out.println("\nFunction: playWithCalculator");	
		Calculator.playWithCalculator();

		System.out.println("\nFunction: playWithFilterMap");
		FilterMapDemo.playWithFilterMap()
			
		// System.out.println("\nFunction: ");		
		// System.out.println("\nFunction: ");		
		// System.out.println("\nFunction: ");		
		// System.out.println("\nFunction: ");		
		// System.out.println("\nFunction: ");		

	} 
}


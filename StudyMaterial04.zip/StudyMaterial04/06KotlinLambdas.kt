
package learnKotlin

//_______________________________________________________

// Function Type
//		(Int, Int) -> Int

fun sum(a: Int, b: Int) = a + b
fun sub(a: Int, b: Int) = a - b

// Higher Order Functions
//		Function Which Takes And/Or Returns Functions

// Function Type
//		(Int, Int, (Int, Int) -> Int) -> Int 
fun calculator( a: Int, b: Int, operation: (Int, Int) -> Int ) : Int {
	return operation( a, b )
}

fun playWithCalculator() {
	val a = 40
	val b = 20
	var result = 0

	result = calculator( a, b, ::sum )
	println("Result = $result ")

	result = calculator( a, b, ::sub )
	println("Result = $result ")

	// What Is The Type Of something?
	val something: (Int, Int) -> Int = ::sum
	result = something( 100, 200 )
	println("Result = $result ")

	val somethingAgain = ::sum
	result = somethingAgain( 100, 200 )
	println("Result = $result ")

	// What Is The Type Of somethingMore?
	val somethingMore = ::calculator
	result = somethingMore(111, 222, ::sum )
	println("Result = $result ")

	val somethingOnceMore: (Int, Int, (Int, Int) -> Int) -> Int = ::calculator
	result = somethingMore(111, 222, ::sum )
	println("Result = $result ")
}

//_______________________________________________________

fun chooseSteps( backward: Boolean ) : (Int) -> Int {
	fun moveForward( start: Int ) : Int {
		return start + 1
	}

	fun moveBackward( start: Int ) : Int {
		return start -  1 
	}

	return	if ( backward ) ::moveBackward else ::moveForward 
}

fun playWithChooseSteps() {
	val something: (Int) -> Int = chooseSteps( true )

	var result = something( 100 )
	println("Result = $result ")

	val somethingMore: (Boolean) -> (Int) -> Int = ::chooseSteps
	val somethingOnceMore: (Int) -> Int = somethingMore( false )
	val YeDilMaangeMore = somethingOnceMore(10)


}

//_______________________________________________________

// fun calculator( a: Int, b: Int, operation: (Int, Int) -> Int ) : Int {
// 	return operation( a, b )
// }

fun playWithLambdas() {
	val a = 40
	val b = 20
	var result = 0

	// Lambda Expression
	//		It Takes Two Int Arguments and Returns Int Value

	// Function Type
	//		(Int, Int) -> Int
	val sumLambda: (Int, Int) -> Int = { a: Int, b: Int  -> a + b }
	result = calculator( a, b, sumLambda )
	println("Result = $result ")

	// Function Type
	//		(Int, Int) -> Int
	val subLambda: (Int, Int) -> Int = { a: Int, b: Int  -> a - b }
	result = calculator( a, b, subLambda )
	println("Result = $result ")
	
	result = calculator( a, b, { a: Int, b: Int  -> a * b } )
	println("Result = $result ")

	// What Is The Type Of something?
	var something: (Int, Int) -> Int = ::sum
	result = something( 100, 200 )
	println("Result = $result ")

	something = sumLambda
	result = something( 100, 200 )
	println("Result = $result ")

	val somethingAgain = ::sum
	result = somethingAgain( 100, 200 )
	println("Result = $result ")

	// What Is The Type Of somethingMore?
	val somethingMore = ::calculator
	result = somethingMore(111, 222, ::sum )
	println("Result = $result ")

	val somethingOnceMore: (Int, Int, (Int, Int) -> Int) -> Int = ::calculator
	result = somethingMore(111, 222, ::sum )
	println("Result = $result ")
}

//_______________________________________________________

fun sum3(a: Int, b: Int, c: Int) = a + b + c

fun playWithLambdasAgain() {
	var someLambda: (Int, Int) -> Int
	var result: Int
	//error: assignment type mismatch: 
	// actual type is 'kotlin.reflect.KFunction3<kotlin.Int, kotlin.Int, kotlin.Int, 
	// kotlin.Int>', 
	// but 'kotlin.Function2<kotlin.Int, kotlin.Int, kotlin.Int>' was expected.
	// someLambda = ::sum3

	someLambda = { a: Int, b: Int -> a * b }
	result = someLambda( 10, 20 )
	println("Result = $result")

	someLambda = { a: Int, b: Int -> Int 
		a * b 
	}
	result = someLambda( 10, 20 )
	println("Result = $result")


	someLambda = { a, b ->  
		a * b 
	}
	result = someLambda( 10, 20 )
	println("Result = $result")

	// var doubleLambda: (Int) -> Int = { a : Int -> 2 * a }
	var doubleLambda = { a : Int -> 2 * a }

	result = doubleLambda( 16 )
	println("Result = $result")	

	doubleLambda = { a : Int -> 
		2 * a 
	}
	result = doubleLambda( 16 )
	println("Result = $result")	

	doubleLambda = { it *  2  }
	result = doubleLambda( 16 )
	println("Result = $result")	

	val square: (Int) -> Int = { number: Int -> number * number }
	result = square( 8 )
	println("Result = $result")	

	val squareAgain: (Int) -> Int = { it * it }
	result = squareAgain( 8 )
	println("Result = $result")	
}

//_______________________________________________________

fun playWithLambdasOnceAgain() {
	var result : Int

	fun operateOnNumbers( a: Int, b: Int, operate: (Int, Int) -> Int ) : Int {
		val result = operate(a, b)
		return result
	}

	val addLambda = { a: Int, b: Int -> a + b }
	result = operateOnNumbers( 33, 11, addLambda )
	println("Result = $result")	

	fun addFunction( a: Int, b: Int ) = a + b
	result = operateOnNumbers( 33, 11, ::addFunction )	
	println("Result = $result")	

	result = operateOnNumbers( 33, 11, operate = ::addFunction )	
	println("Result = $result")	

	result = operateOnNumbers( 33, 11, operate = { a, b -> a + b } )	
	println("Result = $result")	

	result = operateOnNumbers( 33, 11, { a, b -> a + b } )	
	println("Result = $result")	

	// Trailing Lambda Syntax
	result = operateOnNumbers( 33, 11) { a, b -> a + b }
	println("Result = $result")	

	// Trailing Lambda Syntax
	//		Extending Logic With Another Logic
	result = operateOnNumbers( 33, 11 ) { 
		a, b -> a + b 
	}
	println("Result = $result")
}

//_______________________________________________________

class Person(val firstName: String, val lastName: String, val age: Int)

fun playWithLambdaExpressions() {
	val people = listOf( 
		Person("Alice", "Carol", 29),
		Person("Bob", "Macmillan", 32),
		Person("Gabbar", "Singh", 25),
		Person("Basanti", "Gulati", 20)
	)

	val firstNames = people.joinToString( separator = " ", 
						transform = { person: Person -> person.firstName }
					)
	println( firstNames )

	val lastNames = people.joinToString( separator = " ", 
						transform = { person: Person -> person.lastName }
					)
	println( lastNames )

	val ages = people.joinToString( separator = " ", 
						transform = { person: Person -> "${person.age}" }
					)

	println(ages)
}

//_______________________________________________________

// someMagic Can Create Side Effects
// var someMagic = ""

// Higher Order Function
//		Pure Functions
//			Functions Without Side Effects
//			Function Will Give Same Output (Return Value) For Same Inputs( Arguments)
//			(Input, Output) Invariant
fun String.filter( predicate: (Char) -> Boolean ) : String {
	val constructString = StringBuilder()

	for( index in 0 until length ) {
		val element = this.get( index )
		if ( predicate( element ) ) constructString.append( element )
	}
	// Creating Side Effects
	// constructString.append( someMagic )

	return constructString.toString()
}

fun playWithFilterExtensionFunction() {
	val something = "abc12345ABCMU9090kdfkdXYZ"

	val choice1 = { character: Char -> character in 'a'..'z' }
	val choice2 = { character: Char -> character in 'A'..'Z' }
	val choice3 = { character: Char -> character in '0'..'9' }

	var result = something.filter( choice1 )
	println( result )

	result = something.filter( choice2 )
	println( result )

	result = something.filter( choice3 )
	println( result )

	result = something.filter( { character: Char -> character in '0'..'9' } )
	println( result )

	// Trailing Lambda Syntax
	result = something.filter( ) { character: Char -> character in '0'..'9' } 
	println( result )

	// Trailing Lambda Syntax
	result = something.filter { character: Char -> character in '0'..'9' } 
	println( result )

	// Trailing Lambda Syntax
	result = something.filter { 
		character: Char -> character in '0'..'9' 
	} 
	println( result )

}

// abckdfkd
//_______________________________________________________

fun errrorCounts( responses: Collection<String> ) : Pair<Int, Int> {
	var clientErrors = 0
	var serverErrors = 0

	responses.forEach {
		if ( it.startsWith("4") ) {
			clientErrors++
		} else if ( it.startsWith("5")) {
			serverErrors++
		}
 	}

 	// println("Client Errors Count: $clientErrors")
 	// println("Server Errors Count: $serverErrors")
 	return Pair<Int,Int>(clientErrors, serverErrors)
}

fun playWithErrorCounts() {
	val responses = listOf(
		"200 OK",
		"404 Page Not Found",
		"420 Gabbar Singh Found",
		"202 All Is Well!",
		"500 Internal Server Error",
		"000 Focus Well"
	)

	val result = errrorCounts( responses )
	println( result )
}


//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________

fun main() {
	println("\nFunction: playWithCalculator")
	playWithCalculator()

	println("\nFunction: playWithChooseSteps")
	playWithChooseSteps()

	println("\nFunction: playWithLambdas")
	playWithLambdas()

	println("\nFunction: playWithLambdasAgain")
	playWithLambdasAgain()

	println("\nFunction: playWithLambdaExpressions")
	playWithLambdaExpressions()

	println("\nFunction: playWithFilterExtensionFunction")
	playWithFilterExtensionFunction()

	println("\nFunction: playWithErrorCounts")
	playWithErrorCounts()

	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
}


/*
https://codebunk.com/b/4901100677322/
https://codebunk.com/b/4901100677322/
*/

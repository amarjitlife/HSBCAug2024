/*
// Compiling Kotlin Code
kotlinc 03KotlinClasses.kt -include-runtime -d classes.jar

// Running Jar File
java -jar classes.jar
*/

package learnKotlin

//_______________________________________________________
// Practice Code, Moment Done!, Please Raise Your FLAG!!!

// DESIGN PRACTICE
//		Classes Are NOT Meant TO BE Inherited -> MUST BE FINAL
//		Members Are NOT Meant TO BE Overriddedn -> MUST BE FINAL

// In Kotlin
//		Classes Are Final By Default
//			ie. Classes CANNOT Be Inherited
//		Members Are Also Final By Default
//			i.e. Members CANNOT Be Overriden

// In Java
//		Classes Are Open By Default
//			ie. Classes CAN Be Inherited
//		Members Are Also Open By Default
//			i.e. Members CAN Be Overriden

// error: this type is final, so it cannot be extended.
open class View {
	open fun click() = println("View: Clicked Called...")
}

class Button : View() {
	override fun click() = println("Button: Clicked Called...")
	fun magic() = println("Button: Magic Called...")
}

fun View.showOff() = println("View: showOff Called...")
fun Button.showOff() = println("Button: showOff Called...")

fun playWithInheritance() {
	val vo = View()
	vo.click()
	vo.showOff()

	val bo = Button()
	bo.click()
	bo.magic()
	bo.showOff()

	val someone: View = Button()
	someone.click()
	// Seeing Button Type Object w.r.t Parent Type i.e View Type Perceptive
	// error: unresolved reference 'magic'
	// someone.magic()
	// Extension Functions Doens't Participat In Overriding
	someone.showOff()

	val sharmji = someone as Button
	sharmji.click()
	sharmji.magic()
	sharmji.showOff()
}

//_______________________________________________________

open class Parent {
	open fun doStudy() 		= println("Parent: Study Well!")
	open fun doEarn() 		= println("Parent: Earn Well!")
	fun getMarried()		= println("Parent: Get Married!")
}

class Child: Parent() {
	override fun doStudy() 		= println("Child: Study Well!")
	override fun doEarn() 		= println("Child: Earn Well!")
	fun playCricket() 			= println("Child: Play Cricket")
	fun haveSomething() 		= println("Child: Having Fun!!!")
}

fun playWithParentAndChild() {
	val veeru: Parent = Child()

	veeru.doStudy()
	veeru.doEarn()
	veeru.getMarried()

	// error: unresolved reference 'playCricket'.
	// error: unresolved reference 'haveSomething'	
	// veeru.playCricket()
	// veeru.haveSomething()

	val jayFriend = veeru as Child
	jayFriend.playCricket()
	jayFriend.haveSomething()
}

//_______________________________________________________

// In Kotlin
//		By Default 
//		Interfaces Are Open
//		All Interface Members Are Open

// Interfaces
//		Decides What To Do
interface Clickable {
	fun click()
	//	Function With Default Implementation: Use It In Rarest Rare Scenarios
	fun doSomething() = println("Clickable: Doing Something...")
}

interface Focusable {
	fun setFocus()
	fun doSomething() = println("Focusable: Doing Something...")
}

// Concrete Classes
//		Decides How, When, Which, Way, Why, Where...
class ButtonBetter : Clickable, Focusable {
	override fun click() 	= println("ButtonBetter: click Called..")
	override fun setFocus() = println("ButtonBetter: setFocus Called..") 
	fun magic() 			= println("ButtonBetter: magic Called...")

	override fun doSomething() {
		println("ButtonBetter: doSomething Called..")
		// error: multiple supertypes available. 
		// Please specify the intended supertype in angle brackets
		// super.doSomething()
		// CUSTOM LOGIC
		super<Clickable>.doSomething()
		super<Focusable>.doSomething()
	}
}

fun playWithButtonBetter() {
	// val something = Clickable()
	val bbo = ButtonBetter()
	bbo.click() 
	bbo.setFocus()
	bbo.magic()

	// error: class 'ButtonBetter' must override 'doSomething' 
	// because it inherits multiple interface methods for it.
	bbo.doSomething()
}

//_______________________________________________________


enum class Color( val r: Int, val g: Int, val b: Int ) {
	RED(255, 0, 0), GREEN(0, 255, 0), BLUE(0, 0, 255),
	YELLOW( 100, 100, 90 ), PINK( 50, 50, 50 ), ORANGE( 70, 70, 70 )
}

fun getColorName( color: Color ) : String {
	return when( color ) {
		Color.RED 		-> "Red Color"
		Color.GREEN 	-> "Green Color"
		Color.BLUE  	-> "Blue Color"
		Color.YELLOW 	-> "Yellow Color"
		Color.PINK 		-> "Pink Color"
		Color.ORANGE 	-> "Orange Color"
		// else 		-> "Unknown Color" 
	}
}

//_______________________________________________________

interface Expr
class Num( val value: Int ) : Expr
class Sum( val left: Expr, val right: Expr ) : Expr

fun evaluate( e: Expr ) : Int = when( e ) {
	is Num 	-> e.value
	is Sum 	-> evaluate( e.left ) + evaluate( e.right )
	else 	-> throw IllegalArgumentException("Unknown Arguments")
}

fun playWithEvalulate() {
	// 100 + 200
	println( evaluate( Sum( Num(100), Num( 200) ) ) )
	// (  100 + 200 ) + 99
	println( evaluate( Sum( Sum( Num(100), Num(200)), Num(99) ) ) )
}

//_______________________________________________________

sealed class Expression {
	class Num( val value: Int ) : Expression()
	class Sum( val left: Expression, val right: Expression ) : Expression()	
}

fun evaluateOnceAgain( e: Expression ) : Int = when( e ) {
	is Expression.Num 	-> e.value
	is Expression.Sum 	-> evaluateOnceAgain( e.left ) + evaluateOnceAgain( e.right )
	// error: 'when' expression must be exhaustive. Add an 'else' branch
	// else 	-> throw IllegalArgumentException("Unknown Arguments")
}

fun playWithEvalulateOnceAgain() {
	// 100 + 200
	println( evaluateOnceAgain( Expression.Sum( 
		Expression.Num(100), Expression.Num( 200) ) ) 
	)
	// (  100 + 200 ) + 99
	println( evaluateOnceAgain( Expression.Sum( 
		Expression.Sum( Expression.Num(100), Expression.Num(200)), Expression.Num(99) ) ) 
	)
}

//_______________________________________________________

class Client( val name: String, val postalCode: Int ) {
	override fun toString() = "Client(name=$name, postalCode=$postalCode)"
	
	override fun equals( other: Any? ) : Boolean {
		if ( other == null  || other !is Client ) return false 
		return name == other.name && postalCode == other.postalCode
	}
}

fun playWithClient() {
	val gabbar = Client( name = "Gabbar Singh", postalCode = 420420 )	
	println( gabbar.name )
	println( gabbar.postalCode )
	println( gabbar ) // gabbar.toString()

	val gabbar1 = Client( name = "Gabbar Singh", postalCode = 420420 )	
	println( gabbar1.name )
	println( gabbar1.postalCode )
	println( gabbar1 ) // gabbar.toString()

	val basanti = Client("Basanti Gulati", 100100)
	println( basanti.name )
	println( basanti.postalCode )
	println( basanti ) // basanti.toString()

	println( gabbar == gabbar1 )
}

// Gabbar Singh
// 420420
// learnKotlin.Client@548c4f57
// Basanti Gulati
// 100100
// learnKotlin.Client@1218025c

//_______________________________________________________
// DATA CLASSES
//		Compiler Will Generate Following Functions Code
//		1. Will Generate toString With All Properties
//		2. equals Method Code With Comparisson On All Properties
//		3. hashCode Method Code With All Immutable Properties
//		4. copy Method Get Generated

data class ClientAgain( val name: String, val postalCode: Int ) 
// {
// 	override fun toString() = "Client(name=$name, postalCode=$postalCode)"
	
// 	override fun equals( other: Any? ) : Boolean {
// 		if ( other == null  || other !is Client ) return false 
// 		return name == other.name && postalCode == other.postalCode
// 	}
// }

fun playWithClientAgain() {
	val gabbar = ClientAgain( name = "Gabbar Singh", postalCode = 420420 )	
	println( gabbar.name )
	println( gabbar.postalCode )
	println( gabbar ) // gabbar.toString()

	val gabbar1 = ClientAgain( name = "Gabbar Singh", postalCode = 420420 )	
	println( gabbar1.name )
	println( gabbar1.postalCode )
	println( gabbar1 ) // gabbar.toString()

	val basanti = ClientAgain("Basanti Gulati", 100100)
	println( basanti.name )
	println( basanti.postalCode )
	println( basanti ) // basanti.toString()

	println( gabbar == gabbar1 )
}


//_______________________________________________________
// Object Class
//		Singleton Class
//		Singleton Instance Name Is Same As object Class Name

object India {
	fun name() : String {
		return "Baharat!"
	}
}

fun playWithSingleton() {
	val data = India.name()
	println( data )
}

//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
// Practice Code, Moment Done!, Please Raise Your FLAG!!!

fun main() {
	println("\nFunction: playWithInheritance")
	playWithInheritance()

	println("\nFunction: playWithParentAndChild")
	playWithParentAndChild()

	println("\nFunction: playWithButtonBetter")
	playWithButtonBetter()

	println("\nFunction: playWithEvalulateOnceAgain")
	playWithEvalulateOnceAgain()

	println("\nFunction: playWithClient")
	playWithClient()  

	println("\nFunction: playWithClientAgain")
	playWithClientAgain()

	println("\nFunction: playWithSingleton")
	playWithSingleton()

	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
}


/*
https://codebunk.com/b/4901100677322/
https://codebunk.com/b/4901100677322/
https://codebunk.com/b/4901100677322/
*/

android_fundamentals_demo
==================

An app that introduces Android fundamentals 

<img src="http://i.imgur.com/VUAFTHf.png" width="250" />&nbsp;
<img src="http://i.imgur.com/u8yedmR.png" width="250" />

Topics covered:
- Text View 
- Layout Gravity 
- Basic Views
- View Attributes 



